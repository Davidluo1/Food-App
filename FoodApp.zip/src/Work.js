import "./styles.css";
import React from "react";
import Workpage from "./Workpage";
import Data from "./Data";

function Work() {
  const webpage = Data.map((item) => <Workpage id={item.id} {...item} />);
  return <div>{webpage}</div>;
}

export default Work;
