export default function Webpage(props) {
  return (
    <div className="App">
      <nav className="nav-box">
        <ul>
          <li>
            <a href="Home.html">Home</a>
          </li>
          <li>
            <a href="Work.html">Work</a>
          </li>
          <li>
            <a href="list.html">List</a>
          </li>
        </ul>
      </nav>
      <div className="container-1">
        <section className="header">
          <img src={props.img1} alt="" />
          <p>4/29/2021</p>
          <h2>Food is life</h2>
          <p>
            Today is a<span> good </span>
            day to
            <span> play </span>
            tennis
          </p>
          <a
            href="https://www.freecodecamp.org/news/how-to-use-html-to-open-link-in-new-tab/"
            target="_blank"
            rel="noopener noreferrer"
          >
            More information:
          </a>
        </section>
        <section className="item-box">
          <img src={props.img2} alt="" />
          <div className="info">
            <h1>Title1</h1>
            <p>{props.description1}</p>
            <footer>{props.footerName1}</footer>
          </div>
        </section>
        <section className="item-box">
          <img src={props.img3} alt="" />
          <div className="info">
            <h1>Title2</h1>
            <p>{props.description2}</p>
            <footer>{props.footerName2}</footer>
          </div>
        </section>
        <section className="item-box">
          <img src={props.img4} alt="" />
          <div className="info">
            <h1>Title3</h1>
            <p>{props.description3}</p>
            <footer>{props.footerName3}</footer>
          </div>
        </section>
      </div>
      <div className="container-2">
        <section className="introduction">
          <h1>Title1</h1>
          <img src={props.img1} alt="" />
          <p>Description</p>
        </section>
        <div className="items">
          <article>
            <h1>Title2</h1>
            <img src={props.img2} alt="" />
            <p>{props.description1}</p>
          </article>
          <article>
            <h1>Title3</h1>
            <img src={props.img3} alt="" />
            <p>{props.description2}</p>
          </article>
          <article>
            <h1>Title4</h1>
            <img src={props.img4} alt="" />
            <p>{props.description3}</p>
          </article>
        </div>
      </div>
    </div>
  );
}
