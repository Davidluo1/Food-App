export default function Workpage(props) {
  return (
    <div className="App">
      <nav className="nav-box">
        <ul>
          <li>
            <a style={{ textDecoration: "none" }} href="Home.html">
              Home
            </a>
          </li>
          <li>
            <a href="Work.html">Work</a>
          </li>
          <li>
            <a style={{ textDecoration: "none" }} href="list.html">
              List
            </a>
          </li>
        </ul>
      </nav>
    </div>
  );
}
