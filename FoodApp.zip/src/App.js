import "./styles.css";
import React from "react";
import WebPage from "./WebPage";
import Data from "./Data";

// class App extends Component {
//   constructor() {
//     super();
//     this.state = {
//       firstName: "",
//       lastName: "",
//       age: "",
//       birth: "",
//       gender: "",
//       choice: "",
//       completed: false,
//       student: false
//     };
//     this.handleChange = this.handleChange.bind(this);
//   }

//   handleChange(event) {
//     const { name, value, checked, type } = event.target;
//     type === "checkbox"
//       ? this.setState({
//           [name]: checked
//         })
//       : this.setState({
//           [name]: value
//         });
//   }
//   render() {
//     const webpage = Data.map((item) => <WebPage id={item.id} {...item} />);
//     return <div>{webpage}</div>;
//   }
// }
// export default App;

function App() {
  const webpage = Data.map((item) => <WebPage id={item.id} {...item} />);
  return <div>{webpage}</div>;
}

export default App;
