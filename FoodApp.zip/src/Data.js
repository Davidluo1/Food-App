const Data = [
  {
    id: 0,
    img1:
      "https://resources.teletextholidays.co.uk/drupal/images/blogs/s3fs-public/Mexican-food-guide-tacos-hd.jpg",
    img2:
      "https://images-na.ssl-images-amazon.com/images/I/81eB%2B7%2BCkUL._AC_UL200_SR200,200_.jpg",
    img3:
      "https://images-na.ssl-images-amazon.com/images/I/71aLultW5EL._AC_UL200_SR200,200_.jpg",
    img4:
      "https://images-na.ssl-images-amazon.com/images/I/71e5m7xQd0L._AC_UL200_SR200,200_.jpg",
    img5: "",
    description1: "Description1",
    description2: "Description2",
    description3: "Description3",
    description4: "Description4",
    footerName1: "footer1",
    footerName2: "footer2",
    footerName3: "footer3"
  }
];

export default Data;
