import Work from "./Work";
import React from "./react";
import ReactDOM from "react-dom";

const rootElement = document.getElementById("root");
ReactDOM.render(<Work />, rootElement);
